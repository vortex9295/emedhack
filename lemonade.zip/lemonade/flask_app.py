from flask import Flask, render_template, request, redirect, url_for, jsonify
import json
from datetime import datetime

app = Flask(__name__)

# Load habits data from a JSON file
def load_data():
    try:
        with open('habits.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Save habits data to a JSON file
def save_data(data):
    with open('habits.json', 'w') as file:
        json.dump(data, file, indent=4)

@app.route('/')
def home():
    habits = load_data()
    date = datetime.now().strftime("%Y-%m-%d")
    return render_template('index.html', habits=habits, date=date)

@app.route('/add_habit', methods=['POST'])
def add_habit():
    habits = load_data()
    habit_name = request.form['habit_name']
    reminder_time = request.form['reminder_time']
    
    if habit_name not in habits:
        habits[habit_name] = {
            'description': '',
            'dates': {},
            'reminder_time': reminder_time
        }
    save_data(habits)
    return redirect(url_for('home'))

@app.route('/mark_habit', methods=['POST'])
def mark_habit():
    habits = load_data()
    date = datetime.now().strftime("%Y-%m-%d")
    habit_name = request.form['habit_name']

    if habit_name in habits:
        if date in habits[habit_name]['dates'] and habits[habit_name]['dates'][date] == True:
            habits[habit_name]['dates'][date] = False  # Mark as incomplete
        else:
            habits[habit_name]['dates'][date] = True  # Mark as complete

    save_data(habits)
    return redirect(url_for('home'))

@app.route('/delete_habit', methods=['POST'])
def delete_habit():
    habits = load_data()
    habit_name = request.form['habit_name']

    if habit_name in habits:
        del habits[habit_name]

    save_data(habits)
    return redirect(url_for('home'))

@app.route('/edit_description', methods=['POST'])
def edit_description():
    habits = load_data()
    habit_name = request.form['habit_name']
    new_description = request.form['description']

    if habit_name in habits:
        habits[habit_name]['description'] = new_description

    save_data(habits)
    return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=True)
